/*
A stir fry text has the following form. It has gPassages (integer)
texts. This one has 5 passages. Each passage is chopped into gLength 
pieces. gLength is 29 in this stir fry. When the reader places the 
mouse over part n of text t, the program replaces that small text 
with part n of text t+1. 

Each of the gLength HTML elements with id's of j0 to j28, or jwhatever,
if gLength=whatever, holds HTML code. Not necessarily just text.
This means that a stir fry can also involve graphics or any
arbitrary HTML code, not just text. Marko Niemi made a stir fry,
for instance, that displays images, not texts. The stir fry is a
multi-media form. 

Let's look at how the gLength HTML elements j0 to j28 are coded. Below, 
we see an example.

<p id="j24" class="passage0" data-type="t" data-idnum="24">
  whatever<br><i data-type="c">See the data type?</i><br>That data type is important if the text is tagged.
</p>

This is a paragraph (p) element, but the elements can be span or
div or whatever. If an element starts out being a div, it will
remain a div; if it starts out being a p, it will remain a p, etc.

The id starts with j. And is followed by a number between 0 and gLength-1.

The style/class is initially passage0, a style coded in the stylesheet.
As the user stirs the text, the style and content cycle among the 
gPassages passages and styles.

The data-type of these elements must be "t". Note that in our example,
there is inner content like this:
<i data-type="c">Social Values and Poetic Acts</i>
Any tagged inner content must have data-type="c". This is important
for the touchscreen programming to work right.

*/

//****************************************************************
// GLOBALS
//****************************************************************

var gPassages=5;
// This stir fry has 5 passages, ie 5 main texts.
var gPassageStyles=["passage0","passage1","passage2","passage3","passage4"];
// An array of 5 style names, a style for each passage.
var gLength=31;
// Each passage in this stir fry is chopped into 31 pieces.
var gStateOfArt;
// An array of length gLength. Each passage is referred to by
// an index from 0 to gPassages-1. Each element of the gStateOfArt
// array is such an integer. In other words, element x of
// gStateOfArt tells us which passage is currently displayed by
// the HTML node with id='j'+x. All gLength elements are 
// initially 0.
var gTextArray;
// A 2-dimensional array that holds the texts. gTextArray[s][t]
// holds part t of passage s. 
var gCounter=2;
// When the user clicks the image at the bottom, the program
// displays an unstirred passage. This integer is an index
// between 0 and gPassages-1 that indicates which passage
// will be displayed when that button is clicked.

//****************************************************************
// INITIALIZATION
//****************************************************************

window.onload=initialize;  

function initialize() {
	// Runs after window has loaded. Initializes program.
	document.body.addEventListener('touchmove',function(e){
      e.preventDefault();
      // This prevents the body scrolling on the iPad as you
      // 'drag' touch.
  });
	gStateOfArt=[];
	for (var i=0; i<gLength; i++) {
	  gStateOfArt[i]=0;
	}
	// Initializes gStateOfArt to have gLength entries of 0.
	gTextArray = new Array(gPassages);
	for (var i=0; i < gPassages; i++) 
	{   
	  gTextArray[i] = new Array(gLength);  
	}
	// Initializes gTextArray to be a 2-dimensional array.
	gTextArray[0][0] = "Ik ga op vakantie om "
	gTextArray[0][1] = "mijn zintuigen weer "
	gTextArray[0][2] = "te gebruiken. Het idee dat "
	gTextArray[0][3] = "de auto niet zou starten "
	gTextArray[0][4] = "verhoogt "
	gTextArray[0][5] = "mijn hartslag. In de verte hoor ik "
	gTextArray[0][6] = "vrachtwagens voorbij razen. Als ik mij "
	gTextArray[0][7] = "op het geluid focus, "
	gTextArray[0][8] = "kan ik het "
	gTextArray[0][9] = "niet meer onthoren en hoor ik ook "
	gTextArray[0][10] = "alle geluiden om mij heen, de afwezigheid van "
	gTextArray[0][11] = "stilte. Hoe zou volledige stilte klinken? Ik zie "
	gTextArray[0][12] = "een naaldbos. De wind "
	gTextArray[0][13] = "ontbreekt. Ik word rustig als "
	gTextArray[0][14] = "het dondert. Als een boom diep in het bos "
	gTextArray[0][15] = "omvalt en er is niemand "
	gTextArray[0][16] = "om hem te horen vallen, "
	gTextArray[0][17] = "is hij dan gevallen? Regen klettert neer op het dak "
	gTextArray[0][18] = "in de badkamer. De lekkende kraan, "
	gTextArray[0][19] = "geluid uit het verleden dat ik op het nu kleef. Ik laat "
	gTextArray[0][20] = "niet los, "
	gTextArray[0][21] = "stapel hoekige beelden op elkaar en druk aan "
	gTextArray[0][22] = "tot ze in elkaar passen. Iemand "
	gTextArray[0][23] = "speelt piano. Mijn kennis van "
	gTextArray[0][24] = "klassieke muziek "
	gTextArray[0][25] = "is beperkt. Ik vind het "
	gTextArray[0][26] = "mooi, "
	gTextArray[0][27] = "mooier dan "
	gTextArray[0][28] = "als ik het zou herkennen, dan zou ik "
	gTextArray[0][29] = "niet meer echt kunnen luisteren. Het dondert "
	gTextArray[0][30] = "nog steeds. "

	                        
	gTextArray[1][0] = "Ik leerde onlangs dat er zoiets bestaat als"
	gTextArray[1][1] = "het broken heart syndrome. Je hart "
	gTextArray[1][2] = "verandert daadwerkelijk van vorm "
	gTextArray[1][3] = "als je aan liefdesverdriet lijdt. In het Frans "
	gTextArray[1][4] = "heet liefdesverdriet "
	gTextArray[1][5] = "le mal du coeur. Ik zou "
	gTextArray[1][6] = "je kunnen vertellen over "
	gTextArray[1][7] = "de schommel in de tuin,  de plastieken go-kart waarmee we de berg af raceten, mijmeren op het dak met "
	gTextArray[1][8] = "muziek in mijn oren, het diepe rood van de avondlucht, "
	gTextArray[1][9] = "over dat ik vroeg leerde "
	gTextArray[1][10] = "dat seks dingen kapot maakt "
	gTextArray[1][11] = "en dat ik me altijd geschaamd heb, over tegelijkertijd"
	gTextArray[1][12] = "te jong en te oud zijn. Had ik maar geleerd "
	gTextArray[1][13] = "de deur op een kier te zetten "
	gTextArray[1][14] = "in plaats van steeds "
	gTextArray[1][15] = "wijd open als "
	gTextArray[1][16] = "een zwart gat dat de hele wereld opslokt. Ik wil alles "
	gTextArray[1][17] = "in brand steken. Over "
	gTextArray[1][18] = "mijn handpalmen "
	gTextArray[1][19] = "lopen nieuwe lijnen: mijn hartlijn is "
	gTextArray[1][20] = "krommer geworden, mijn levenslijn korter. Op de rug "
	gTextArray[1][21] = "van mijn hand "
	gTextArray[1][22] = "staan kleine pigmentvlekken, "
	gTextArray[1][23] = "daar gebrand door een zon die "
	gTextArray[1][24] = "feller is dan "
	gTextArray[1][25] = "de zon die thuis "
	gTextArray[1][26] = "in de hemel klimt. Ik wil iemand "
	gTextArray[1][27] = "die ik niet ken "
	gTextArray[1][28] = "bij de hand nemen "
	gTextArray[1][29] = "en samen "
	gTextArray[1][30] = "een huis in wandelen. "


	gTextArray[2][0] = "Eens alles ingepakt was, "
	gTextArray[2][1] = "zat er niets anders op dan vertrekken. De deur achter mij "
	gTextArray[2][2] = "dicht trekken. Het slot omdraaien. De sleutel "
	gTextArray[2][3] = "veilig in mijn zak opbergen. Binnen handbereik, "
	gTextArray[2][4] = "ik zou me nog om zou kunnen keren "
	gTextArray[2][5] = "als ik dat wilde. Hoe "
	gTextArray[2][6] = "zal mijn stem klinken als "
	gTextArray[2][7] = "ik mijn mond opendoe? Zal "
	gTextArray[2][8] = "ik mij eenzaam voelen, "
	gTextArray[2][9] = "zal dat gevoel "
	gTextArray[2][10] = "zich uitspreiden over mijn borstkas "
	gTextArray[2][11] = "en als wildgroei gaan woekeren? "
	gTextArray[2][12] = "Als ik dit precies aanpak, "
	gTextArray[2][13] = "zal de onrust klein blijven, "
	gTextArray[2][14] = "zoals een balletje, een poppetje in een doosje. Ik weet niet "
	gTextArray[2][15] = "welk verhaal "
	gTextArray[2][16] = "ik wil vertellen, " 
	gTextArray[2][17] = "een over een permanente zonsopgang misschien. "
	gTextArray[2][18] = "Ik kan gelukkig "
	gTextArray[2][19] = "worden vandaag, "
	gTextArray[2][20] = "een glimlach van de straat rapen. "
	gTextArray[2][21] = "Ik geloof niet in "
	gTextArray[2][22] = "mijn eigen woorden. Geloof "
	gTextArray[2][23] = "is niet noodzakelijk. Niet "
	gTextArray[2][24] = "altijd. Ik probeer me te herinneren "
	gTextArray[2][25] = "wanneer ik voor het laatst "
	gTextArray[2][26] = "gedanst "
	gTextArray[2][27] = "heb. Zij die mensen "
	gTextArray[2][28] = "aan durven te raken "
	gTextArray[2][29] = "veranderen "
	gTextArray[2][30] = "de wereld. "

	                          

	gTextArray[3][0] = "Ik wil op een man lijken die "
	gTextArray[3][1] = "iedere ochtend "
	gTextArray[3][2] = "de krant leest en telkens hetzelfde ontbijt kan eten zonder "
	gTextArray[3][3] = "zichzelf van kant te willen maken. Mijn huid kleeft aan "
	gTextArray[3][4] = "de bodem van het moeras dat mijn leven is. "
	gTextArray[3][5] = "Zo voelt het soms. Soms voelt het alsof "
	gTextArray[3][6] = "ik vlieg. Al vlieg ik nog zelden "
	gTextArray[3][7] = "op eigen krachten, "
	gTextArray[3][8] = "meestal komt er muziek bij kijken, "
	gTextArray[3][9] = "literatuur, koffie, sigaretten, alcohol, andere verdovende of hallicunogene middelen. In vervlogen tijden "
	gTextArray[3][10] = "was het leven zelf mijn hallucinogeen: ik stond op, ademde "
	gTextArray[3][11] = "alle deeltjes van de wereld in, "
	gTextArray[3][12] = "stond te trillen op mijn benen, overweldigd, "
	gTextArray[3][13] = "gelovig, vol. Ik ben "
	gTextArray[3][14] = "een kraantje dat ik open kan zetten, "
	gTextArray[3][15] = "maar niet meer "
	gTextArray[3][16] = "dicht kan draaien. "
	gTextArray[3][17] = "Als ik te lang nadenk "
	gTextArray[3][18] = "over wie ik geworden ben "
	gTextArray[3][19] = "loop ik in een keer "
	gTextArray[3][20] = "leeg. Ik droom van "
	gTextArray[3][21] = "water dat uit een rivier op rotsen stroomt. Ik droom "
	gTextArray[3][22] = "dat ik die rotsen ben. Mijn lichaam "
	gTextArray[3][23] = "poreus en doordringbaar. Zoals wanneer ik woorden wil geven aan iets moois: "
	gTextArray[3][24] = "hoe de zon door het raam "
	gTextArray[3][25] = "schuin op de muur invalt, de spullen "
	gTextArray[3][26] = "netjes opgeborgen in de kast "
	gTextArray[3][27] = "om mijzelf het gevoel te geven "
	gTextArray[3][28] = "dat ik"
	gTextArray[3][29] = "hier"
	gTextArray[3][30] = "zal blijven. "


	                          
	gTextArray[4][0] = "Ik sta "
	gTextArray[4][1] = "naakt voor de spiegel. Zie waar "
	gTextArray[4][2] = "mijn buik bolt bij iedere ademhaling. Hoe "
	gTextArray[4][3] = "mijn schouders een beetje naar voren hellen. "
	gTextArray[4][4] = "De grote moedervlek die als kind lager op mijn heup "
	gTextArray[4][5] = "zat. De ogen "
	gTextArray[4][6] = "turend, als "
	gTextArray[4][7] = "die van een vreemde. Wanneer ik lang genoeg kijk, "
	gTextArray[4][8] = "ben ik het spiegelbeeld "
	gTextArray[4][9] = "niet meer. Ik teken het landschap na, "
	gTextArray[4][10] = "de krommende bergen, "
	gTextArray[4][11] = "verre bomen, "
	gTextArray[4][12] = "de lucht die erboven hangt. Ergens "
	gTextArray[4][13] = "in de tekening zit "
	gTextArray[4][14] = "mijn kijken vervat. De hand die als antwoord op "
	gTextArray[4][15] = "het kijken een lijn trok, hem liet golven en "
	gTextArray[4][16] = "neerkomen onderaan de pagina. Ik wou "
	gTextArray[4][17] = "er graag "
	gTextArray[4][18] = "een punt achter zetten, maar "
	gTextArray[4][19] = "de tekening was "
	gTextArray[4][20] = "nooit af en was al niet "
	gTextArray[4][21] = "wat ik wilde dat hij werd "
	gTextArray[4][22] = "bij de eerste impuls "
	gTextArray[4][23] = "om iets op papier te zetten. Ik heb mezelf "
	gTextArray[4][24] = "weggerukt "
	gTextArray[4][25] = "om een reden die nu onbegrijpelijk lijkt: "
	gTextArray[4][26] = "om weg te zijn. De afstand katapulteert mij alleen maar naar "
	gTextArray[4][27] = "huis. Ik zie "
	gTextArray[4][28] = "ieder nietszeggend detail voor me als was het "
	gTextArray[4][29] = "de samenvatting van "
	gTextArray[4][30] = "mijn leven. "

	setBindings();
	resizeBrowser();
}; // end of initialize

function setBindings() {
  // Called once. Toward the end of initialize.
  window.addEventListener("resize", resizeBrowser, false);
  if (isEventSupported("touchmove")) {
    //set up touch handling
    var maintextobj=document.getElementById("maintext");
    document.body.addEventListener("touchstart", touchInProgress, false);
    document.body.addEventListener("touchmove", touchInProgress, false);
  }
  else {
    // Mouse handling
    for (var i=0; i<gLength; i++) {
      document.getElementById('j' + i).addEventListener("mouseover", cutupMouse, false);
    }
  }
} // end of setBindings

//****************************************************************
// FUNCTIONS
//****************************************************************

function resizeBrowser() {
	// Called at the beginning of the program and when the user resizes the browser.
	var bh=browserHeight();
	var mainTextHeight=bh - elementHeight(document.getElementById('title'));
	var textHeight=elementHeight('maintext');
	if (mainTextHeight>=textHeight) {
		document.getElementById('maintext').style.top=Math.round(0.5*(mainTextHeight-textHeight)/2) + 'px';
	}
	else {
			document.getElementById('maintext').style.top='0px';
	}
}

function cutupMouse() {
	// This gets called each time the mouseover event occurs over
	// one of the html elements with id such as j0 or j5 etc.
  var x=this.getAttribute("data-idnum");
  var xint=parseInt(x);
  gStateOfArt[xint]=(gStateOfArt[xint]+1) % gPassages;
  // When the reader places the mouse over part n of text t, the 
  //program replaces that small text with part n of text t+1. 
  cutup(this, gStateOfArt[xint], xint);
}

function cutup(Textian, jstate, jposition) {
	// Gets called each time the program stirs the text.
	// Textian is the html object. jstate is the number
	// of the passage. jposition is the number of the part.
  Textian.innerHTML=gTextArray[jstate][jposition];
  Textian.className=gPassageStyles[jstate];
}

function touchInProgress(e) {
	// Gets called each time the user stirs the text on a touchscreen.
	var touch = e.touches[0];
	var x = touch.pageX;
	var y = touch.pageY;
	var el= document.elementFromPoint(x,y); 
	//el is the topmost element the user is touching.
	if (el) {
    var dataType=el.getAttribute('data-type');
    // Each of the gLength HTML elements with id of j0 or j24
    // (or whatever) have data-type="t". Tagged inner content
    // of those elements must have data-type="c".
    if (dataType) {
    	// Then el is either one of our j0 to j24 elements or
    	// an element inside those.
    	while (dataType != 't') {
    		// This loop ensures that el ends up being one of our
    		// targeted j0 to j24 elements.
    		el=el.parentNode;
    		dataType=el.getAttribute('data-type');
    	}
    	var idnumasstring=el.getAttribute("data-idnum");
	    if (idnumasstring) {
	      var idnum=parseInt(idnumasstring);
	      gStateOfArt[idnum]=(gStateOfArt[idnum]+1)%gPassages;
	      cutup(el, gStateOfArt[idnum], idnum);
	    }

    }
	}
} // end of touchInProgress

function order() {
	// Called when the user clicks the button that
	// cycles through the texts.
	gCounter=(gCounter+1) % gPassages;
	for (var i=0; i<gLength; i++) {
		var el=document.getElementById("j"+i)
		el.innerHTML = gTextArray[gCounter][i];
		el.className=gPassageStyles[gCounter];
	}
	resizeBrowser();
}

/*
	var maintext=document.getElementById('maintext');
  for (var i=0; i<gLength; i++) {
	  var n=document.createElement('span');
	  n.setAttribute('id', 'j'+i);
	  n.setAttribute('class', gPassageStyles[gCounter]);
	  n.setAttribute('data-type', 't');
	  n.setAttribute('data-idnum', i.toString());
	  n.innerHTML=gTextArray[gCounter][i];
	  gObjArray[i]=n;
	  maintext.appendChild(n);
	}
	*/